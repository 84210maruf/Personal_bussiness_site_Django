from django.contrib import admin
from .models import ProfileName,ProfileTitle,ContactMessage,Author,AuthorAbout,Cunsultancy,ConseltancyAbout,Sharing

# Admin site data view control

class adminProfileTitle(admin.ModelAdmin):
    list_display = ['id','title']

class adminContactMsg(admin.ModelAdmin):
    list_display = ['id','name', 'email', 'message']

class adminAuthor(admin.ModelAdmin):
    list_display = ['id', 'descriptions']

class adminAuthorAbout(admin.ModelAdmin):
    list_display = ['title','checkMark01','checkMark02']

class adminConseltancy(admin.ModelAdmin):
    list_display = ['id','descriptions']

class adminConseltancyAbout(admin.ModelAdmin):
    list_display = ['title','checkMark01','checkMark02']

class adminSharing(admin.ModelAdmin):
    list_display = ['title','description']

# Register your models here.
admin.site.register(ProfileName)
admin.site.register(ProfileTitle, adminProfileTitle)
admin.site.register(ContactMessage, adminContactMsg)
admin.site.register(Author, adminAuthor)
admin.site.register(AuthorAbout, adminAuthorAbout)
admin.site.register(Cunsultancy, adminConseltancy)
admin.site.register(ConseltancyAbout, adminConseltancyAbout)
admin.site.register(Sharing, adminSharing)


