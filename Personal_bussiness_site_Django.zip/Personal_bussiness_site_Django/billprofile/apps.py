from django.apps import AppConfig


class BillprofileConfig(AppConfig):
    name = 'billprofile'
