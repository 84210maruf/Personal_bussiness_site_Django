from django.db import models


# Create your models here.

class ProfileName(models.Model):
    name = models.CharField(max_length=100, blank=False)
    imag = models.ImageField(upload_to='profile/',blank=False)
    def __str__(self):
        return self.name

class ProfileTitle(models.Model):
    title = models.TextField(max_length=300, blank=False)
    def __str__(self):
        return self.title

class ContactMessage(models.Model):
    name = models.CharField(max_length=100, blank=True)
    email = models.CharField(max_length=50, blank=True)
    message = models.TextField(max_length=1000,blank=True)

    def __str__(self):
        return self.name

# Author TAB
class Author(models.Model):
    descriptions = models.TextField(max_length=1000, blank=False)
    def __str__(self):

        return self.descriptions

class AuthorAbout(models.Model):
    title = models.CharField(max_length=100, blank=False)
    description = models.TextField(max_length=300, blank=False)
    imag = models.ImageField(upload_to='author/', blank=False)
    checkMark01 = models.CharField(max_length=100, blank=False)
    checkMark02 = models.CharField(max_length=100, blank=False)

    def __str__(self):
        return self.title

# Consultancy TAB
class Cunsultancy(models.Model):
    descriptions = models.TextField(max_length=1000, blank=False)
    def __str__(self):

        return self.descriptions

class ConseltancyAbout(models.Model):
    title = models.CharField(max_length=100, blank=False)
    description = models.TextField(max_length=300, blank=False)
    imag = models.ImageField(upload_to='author/', blank=False)
    checkMark01 = models.CharField(max_length=100, blank=False)
    checkMark02 = models.CharField(max_length=100, blank=False)

    def __str__(self):
        return self.title

class Sharing(models.Model):
    title = models.CharField(max_length=100, blank=False)
    description = models.TextField(max_length=300, blank=False)
    imag = models.ImageField(upload_to='author/', blank=False)

    def __str__(self):
        return self.title


"""
class about(models.Model):
    title = models.CharField(max_length=100,blank=False)
    description = models.TextField(max_length=500,blank=False)
    image = models.ImageField(upload_to='about/',blank=False)
    def __str__(self):
        return self.title

class slider(models.Model):
    title = models.CharField(max_length=100,blank=False)
    description = models.TextField(max_length=500,blank=False)
    image = models.ImageField(upload_to='slider/',blank=False)
    def __str__(self):
        return self.title

class client(models.Model):
    name = models.CharField(max_length=100,blank=False)
    link = models.CharField(max_length=400, blank=False)
    image = models.ImageField(upload_to='client/',blank=False)
    def __str__(self):
        return self.name
"""
