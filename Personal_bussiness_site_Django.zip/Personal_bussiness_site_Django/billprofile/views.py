from django.shortcuts import render, HttpResponse
from django.views import View
from .models import ProfileName,ProfileTitle,ContactMessage,Author,AuthorAbout,Cunsultancy,ConseltancyAbout,Sharing

# Create your views here.

def profile(request):
    # Profile
    profiles = ProfileName.objects.all()[0]
    prfile_title = ProfileTitle.objects.all()
    # Author
    author_des = Author.objects.all()[0]
    author_about = AuthorAbout.objects.all()
    # Consultancy
    consul_des = Cunsultancy.objects.all()[0]
    consul_about = ConseltancyAbout.objects.all()
    # Sharing
    sharing = Sharing.objects.all()

    # Contact message from users
    if request.method == 'POST':
        msgName = request.POST.get('name')
        msgEmail = request.POST.get('email')
        msg = request.POST.get('message')
        print(type(msgName), msgEmail, msg)

        contact_data = ContactMessage(name=msgName, email=msgEmail, message=msg)
        if not msgEmail == str(None):
            contact_data.save()


    context = {
        'profiles': profiles,
        'profile_title': prfile_title,
        'authorDes': author_des,
        'authorAbout': author_about,
        'conseltDes': consul_des,
        'consultAbout': consul_about,
        'sharing': sharing
    }
    return render(request, 'index.html', context)